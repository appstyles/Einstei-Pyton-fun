# Einstein Relativity Lab V2

A small interactive Python/Tkinter visualization inspired by Einstein's equations.

## Features

- `E = mc²`
- Schwarzschild radius
- Simple gravitational time dilation display
- Animated spacetime grid
- Earth, Sun, and Black Hole presets
- Animated energy beam and graph
- Optional PNG export

## Requirements

- Python 3.10+
- Tkinter
- Pillow (optional, only required for PNG export)

Install Pillow:

```bash
pip install -r requirements.txt
```

## Run

```bash
python main.py
```

## Notes

This project is an educational and artistic visualization. It is not a full numerical simulation of general relativity.

## Formulae

```text
E = mc²

r_s = 2GM / c²

time factor = sqrt(1 - r_s / r)
```

## License

MIT
