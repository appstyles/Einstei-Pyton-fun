import tkinter as tk
import math
import random
import time

try:
    from PIL import ImageGrab
    PIL_AVAILABLE = True
except Exception:
    PIL_AVAILABLE = False

C = 299_792_458
G = 6.67430e-11


class EinsteinLab:
    def __init__(self, root):
        self.root = root
        self.root.title("Einstein Relativity Lab V2")

        self.W = 1280
        self.H = 760

        self.canvas = tk.Canvas(
            root,
            width=self.W,
            height=self.H,
            bg="#02050a",
            highlightthickness=0
        )
        self.canvas.pack()

        self.running = True
        self.mass_kg = 5.972e24
        self.radius_m = 6.371e6
        self.time = 0

        self.stars = []
        self.mouse_x = 0
        self.mouse_y = 0

        self.create_stars()

        self.canvas.bind("<Button-1>", self.mouse_click)
        self.canvas.bind("<Motion>", self.mouse_move)

        self.animate()

    def energy(self):
        return self.mass_kg * C**2

    def schwarzschild_radius(self):
        return (2 * G * self.mass_kg) / C**2

    def time_dilation(self):
        rs = self.schwarzschild_radius()
        if self.radius_m <= rs:
            return 0.0
        return math.sqrt(1 - rs / self.radius_m)

    def create_stars(self):
        for _ in range(180):
            self.stars.append(
                (
                    random.randint(0, self.W),
                    random.randint(0, self.H),
                    random.choice([1, 1, 1, 2])
                )
            )

    def draw_stars(self):
        for x, y, r in self.stars:
            flicker = random.randint(170, 255)
            color = f"#{flicker:02x}{flicker:02x}{flicker:02x}"

            self.canvas.create_oval(
                x-r, y-r, x+r, y+r,
                fill=color,
                outline=""
            )

    def draw_spacetime_grid(self):
        cx = 330
        cy = 390

        mass_factor = min(math.log10(self.mass_kg + 1) / 30, 1)
        warp = 350 * mass_factor

        for x in range(80, 580, 35):
            points = []

            for y in range(220, 620, 8):
                dx = x - cx
                dy = y - cy
                distance = dx*dx + dy*dy + 800
                bend = warp / distance

                px = x - dx * bend * 35
                py = y - dy * bend * 35
                points.extend([px, py])

            self.canvas.create_line(
                points,
                fill="#133f62",
                width=1,
                smooth=True
            )

        for y in range(220, 620, 35):
            points = []

            for x in range(80, 580, 8):
                dx = x - cx
                dy = y - cy
                distance = dx*dx + dy*dy + 800
                bend = warp / distance

                px = x - dx * bend * 35
                py = y - dy * bend * 35
                points.extend([px, py])

            self.canvas.create_line(
                points,
                fill="#133f62",
                width=1,
                smooth=True
            )

    def draw_mass(self):
        cx = 330
        cy = 390
        pulse = 6 * math.sin(self.time * 0.06)
        radius = 45

        for i in range(4):
            r = radius + 14 + i * 12 + pulse
            self.canvas.create_oval(
                cx-r, cy-r, cx+r, cy+r,
                outline="#204d91",
                width=1
            )

        self.canvas.create_oval(
            cx-radius, cy-radius,
            cx+radius, cy+radius,
            fill="#2a7fd4",
            outline="#9edcff",
            width=3
        )

        self.canvas.create_oval(
            cx-25, cy-25,
            cx+5, cy+5,
            fill="#86d8ff",
            outline=""
        )

        self.canvas.create_text(
            cx,
            cy + 80,
            text="Massive Object",
            fill="white",
            font=("Arial", 13, "bold")
        )

    def draw_energy_beam(self):
        y = 390
        start = 430
        end = 760

        amplitude = 18 + 8 * math.sin(self.time * 0.05)
        points = []

        for x in range(start, end, 6):
            wave = y + math.sin(x * 0.05 + self.time * 0.15) * amplitude
            points.extend([x, wave])

        self.canvas.create_line(
            points,
            fill="#ffb52e",
            width=6,
            smooth=True
        )

        self.canvas.create_line(
            points,
            fill="#fff0a6",
            width=2,
            smooth=True
        )

        self.canvas.create_text(
            590,
            340,
            text="E = mc²",
            fill="white",
            font=("Arial", 28, "bold")
        )

    def draw_energy_core(self):
        cx = 880
        cy = 390
        pulse = 10 + 8 * math.sin(self.time * 0.12)

        for i in range(5):
            r = 50 + i * 18 + pulse
            self.canvas.create_oval(
                cx-r, cy-r, cx+r, cy+r,
                outline="#00aaff",
                width=1
            )

        self.canvas.create_oval(
            cx-pulse, cy-pulse,
            cx+pulse, cy+pulse,
            fill="white",
            outline=""
        )

        self.canvas.create_text(
            cx,
            cy + 125,
            text="Energy Output",
            fill="#91e6ff",
            font=("Arial", 13, "bold")
        )

    def draw_graph(self):
        x1 = 990
        y1 = 260
        x2 = 1230
        y2 = 500

        self.canvas.create_rectangle(
            x1, y1, x2, y2,
            outline="#245176",
            width=2
        )

        self.canvas.create_text(
            1110,
            235,
            text="Space-Time Graph",
            fill="#9adfff",
            font=("Arial", 13, "bold")
        )

        self.canvas.create_line(
            x1 + 20,
            y2 - 30,
            x2 - 15,
            y2 - 30,
            fill="#607d8b"
        )

        self.canvas.create_line(
            x1 + 20,
            y1 + 20,
            x1 + 20,
            y2 - 30,
            fill="#607d8b"
        )

        points = []

        for i in range(190):
            x = x1 + 25 + i
            value = math.sin(i * 0.08 + self.time * 0.08)
            y = 380 + value * 45
            points.extend([x, y])

        self.canvas.create_line(
            points,
            fill="#00ddff",
            width=2,
            smooth=True
        )

    def draw_info(self):
        energy = self.energy()
        rs = self.schwarzschild_radius()
        dilation = self.time_dilation()

        self.canvas.create_rectangle(
            70, 640, 1210, 730,
            fill="#06111c",
            outline="#234e70",
            width=2
        )

        lines = [
            f"Mass: {self.mass_kg:.3e} kg",
            f"Energy: {energy:.3e} J",
            f"Schwarzschild radius: {rs:.6f} m",
            f"Gravitational time factor: {dilation:.12f}"
        ]

        y = 660

        for text in lines:
            self.canvas.create_text(
                95,
                y,
                text=text,
                fill="#bcefff",
                anchor="w",
                font=("Consolas", 12)
            )
            y += 18

        self.canvas.create_text(
            760,
            680,
            text="Simulation + visual emulation\nbased on Einstein's equations",
            fill="#ffdc86",
            font=("Arial", 13, "bold"),
            justify="center"
        )

    def draw_header(self):
        self.canvas.create_text(
            self.W/2,
            55,
            text="EINSTEIN RELATIVITY LAB V2",
            fill="#dffaff",
            font=("Arial", 28, "bold")
        )

        self.canvas.create_text(
            self.W/2,
            90,
            text="Energy • Gravity • Space-Time • Simulation • Emulation",
            fill="#6fc8ff",
            font=("Arial", 13)
        )

        self.canvas.create_text(
            self.W/2,
            125,
            text="E = mc²",
            fill="#ffdc79",
            font=("Arial", 22, "bold")
        )

    def draw_buttons(self):
        buttons = [
            ("EARTH", 70),
            ("SUN", 180),
            ("BLACK HOLE", 290),
            ("EXPORT PNG", 440)
        ]

        for text, x in buttons:
            self.canvas.create_rectangle(
                x, 150, x + 120, 190,
                fill="#08192a",
                outline="#2979aa",
                width=2
            )

            self.canvas.create_text(
                x + 60,
                170,
                text=text,
                fill="#c6efff",
                font=("Arial", 10, "bold")
            )

    def mouse_click(self, event):
        x = event.x
        y = event.y

        if 150 <= y <= 190:
            if 70 <= x <= 190:
                self.mass_kg = 5.972e24
                self.radius_m = 6.371e6

            elif 180 <= x <= 300:
                self.mass_kg = 1.989e30
                self.radius_m = 6.9634e8

            elif 290 <= x <= 410:
                self.mass_kg = 10 * 1.989e30
                self.radius_m = self.schwarzschild_radius() * 1.1

            elif 440 <= x <= 560:
                self.export_png()

    def mouse_move(self, event):
        self.mouse_x = event.x
        self.mouse_y = event.y

    def export_png(self):
        if not PIL_AVAILABLE:
            print("Install Pillow first: pip install pillow")
            return

        self.root.update()

        x = self.root.winfo_rootx() + self.canvas.winfo_x()
        y = self.root.winfo_rooty() + self.canvas.winfo_y()
        x2 = x + self.canvas.winfo_width()
        y2 = y + self.canvas.winfo_height()

        filename = "einstein_lab_" + str(int(time.time())) + ".png"

        image = ImageGrab.grab(
            bbox=(x, y, x2, y2)
        )

        image.save(filename)
        print("Saved:", filename)

    def animate(self):
        self.canvas.delete("all")

        self.draw_stars()
        self.draw_header()
        self.draw_buttons()
        self.draw_spacetime_grid()
        self.draw_mass()
        self.draw_energy_beam()
        self.draw_energy_core()
        self.draw_graph()
        self.draw_info()

        if self.running:
            self.time += 1

        self.root.after(33, self.animate)


if __name__ == "__main__":
    root = tk.Tk()
    app = EinsteinLab(root)
    root.mainloop()
